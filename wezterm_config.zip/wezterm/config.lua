local wezterm = require("wezterm")
local config = {}

-- Construire la config avec wezterm.config_builder si disponible
if wezterm.config_builder then
  config = wezterm.config_builder()
end

-- Configuration principale
config.default_cursor_style = "BlinkingBar"
config.automatically_reload_config = true
config.window_close_confirmation = "NeverPrompt"
config.adjust_window_size_when_changing_font_size = false
config.window_decorations = "RESIZE"
config.check_for_updates = false
config.use_fancy_tab_bar = false
config.tab_bar_at_bottom = false
config.enable_tab_bar = false

config.check_for_updates = true
config.check_for_updates_interval_seconds = 86400
-- Taille de la fenêtre
config.initial_rows = 52
config.initial_cols = 200

-- Fontes
config.font_size = 12
config.font = wezterm.font("JetBrains Mono", { weight = "Bold" })

-- Padding de la fenêtre
config.window_padding = {
  left = 18,
  right = 15,
  top = 15,
  bottom = 15,
}

-- Schéma de couleur
config.color_scheme = "Gruvbox"
config.window_background_opacity = 0.95

wezterm.on("update-status", function(window, pane)
  -- Exécuter Starship et récupérer son résultat
  local success, stdout = wezterm.run_child_process({"starship", "prompt"})

  -- Formatter le texte à afficher dans la barre d'état
  local date = wezterm.strftime("%Y-%m-%d %H:%M:%S")
  local status_text = stdout:gsub("\n", "") .. " | " .. date

  -- Appliquer le texte dans la status line
  window:set_right_status(wezterm.format({
    { Text = status_text },
  }))
end)
-- Fond d'écran avec une image
-- config.background = {
--   {
--     source = {
--       File = "/home/candriam/Downloads/sv.png",
--     },
--     width = "100%",
--     height = "100%",
--     opacity = 0.25, -- Ajuster l'opacité si nécessaire
--   },
-- }

-- Configuration des hyperliens
config.hyperlink_rules = {
  {
    regex = "\\((\\w+://\\S+)\\)",
    format = "$1",
    highlight = 1,
  },
  {
    regex = "\\[(\\w+://\\S+)\\)",
    format = "$1",
    highlight = 1,
  },
  {
    regex = "\\{(\\w+://\\S+)\\}",
    format = "$1",
    highlight = 1,
  },
  {
    regex = "<(\\w+://\\S+)>",
    format = "$1",
    highlight = 1,
  },
  {
    regex = "[^(]\\b(\\w+://\\S+[)/a-zA-Z0-9-]+)",
    format = "$1",
    highlight = 1,
  },
  {
    regex = "\\b\\w+@[\\w-]+(\\.[\\w-]+)+\\b",
    format = "mailto:$0",
  },
}

return config

