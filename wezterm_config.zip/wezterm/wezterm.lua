local wezterm = require("wezterm")
local mux = wezterm.mux

-- Initialisation de la configuration
local config = {}

-- Config Builder (si disponible)
if wezterm.config_builder then
  config = wezterm.config_builder()
end

-- Paramètres de base
config.term = "wezterm"
config.default_workspace = "main"
config.window_decorations = "RESIZE"
config.default_cursor_style = 'BlinkingBar'
config.window_background_opacity = 0.98
config.check_for_updates = false
config.hide_tab_bar_if_only_one_tab = true
config.native_macos_fullscreen_mode = false
config.use_fancy_tab_bar = true  -- Activation de la barre des onglets avec un style visuel
config.tab_bar_at_bottom = false  -- Positionner la barre des onglets en haut
config.enable_tab_bar = true  -- Activer la barre des onglets

-- Paramètres de la fenêtre
config.window_padding = {
  left = 10,
  right = 10,
  top = 5,
  bottom = 5,
}
config.initial_rows = 52
config.initial_cols = 200

-- Ajuster la saturation et la luminosité des panneaux inactifs
config.inactive_pane_hsb = {
  saturation = 0.7,
  brightness = 0.7,
}

-- Police et taille de la police
config.font_size = 12
config.font = wezterm.font("JetBrains Mono", { weight = "Bold" })

-- Schéma de couleur basé sur la variable d'environnement
local success, stdout = wezterm.run_child_process({ os.getenv("SHELL"), "-c", "printenv WEZTERM_THEME" })
local selected_theme = stdout:gsub("%s+", "")
config.color_scheme = selected_theme ~= "" and selected_theme or "Gruvbox dark, soft (base16)"

-- Personnalisation des onglets
config.colors = {
  tab_bar = {
    background = "#282828", -- Gruvbox dark background
    active_tab = {
      bg_color = "#282828", -- Fond actif
      fg_color = "#fabd2f", -- Texte en jaune
      intensity = "Bold",
    },
    inactive_tab = {
      bg_color = "#3c3836", -- Fond des onglets inactifs
      fg_color = "#928374", -- Texte en gris
    },
    inactive_tab_hover = {
      bg_color = "#504945", -- Fond survolé
      fg_color = "#ebdbb2", -- Texte en blanc cassé
      italic = true,
    },
    new_tab = {
      bg_color = "#282828",
      fg_color = "#83a598", -- Bleu doux pour Gruvbox
    },
    new_tab_hover = {
      bg_color = "#282828",
      fg_color = "#d3869b", -- Rose doux pour Gruvbox
      italic = true,
    },
  },
}

-- Raccourcis clavier
config.keys = {
  { key = "e", mods = "ALT", action = wezterm.action.SplitHorizontal({ domain = "CurrentPaneDomain" }) },
  { key = "d", mods = "ALT", action = wezterm.action.SplitVertical({ domain = "CurrentPaneDomain" }) },
  { key = "w", mods = "ALT", action = wezterm.action.CloseCurrentPane({ confirm = false }) },
  { key = "UpArrow", mods = "ALT", action = wezterm.action.ActivatePaneDirection("Up") },
  { key = "DownArrow", mods = "ALT", action = wezterm.action.ActivatePaneDirection("Down") },
  { key = "LeftArrow", mods = "ALT", action = wezterm.action.ActivatePaneDirection("Left") },
  { key = "RightArrow", mods = "ALT", action = wezterm.action.ActivatePaneDirection("Right") },
}

-- Événements
wezterm.on("gui-startup", function()
  local _, _, window = mux.spawn_window({
    initial_rows = config.initial_rows,
    initial_cols = config.initial_cols,
  })
end)

-- Configuration de la barre d'état avec Starship
--wezterm.on("update-status", function(window, pane)
--  local success, stdout = wezterm.run_child_process({"starship", "prompt"})
--  local date = wezterm.strftime("%Y-%m-%d %H:%M:%S")
--  local status_text = stdout:gsub("\n", "") .. " | " .. date
--
--  window:set_right_status(wezterm.format({
--    { Text = status_text },
--  }))
--end)

-- Configuration des hyperliens
config.hyperlink_rules = {
  { regex = "\\((\\w+://\\S+)", format = "$1", highlight = 1 },
  { regex = "\\[(\\w+://\\S+)", format = "$1", highlight = 1 },
  { regex = "\\{(\\w+://\\S+)", format = "$1", highlight = 1 },
  { regex = "<(\\w+://\\S+)>", format = "$1", highlight = 1 },
  { regex = "[^(]\\b(\\w+://\\S+[)/a-zA-Z0-9-]+)", format = "$1", highlight = 1 },
  { regex = "\\b\\w+@[\\w-]+(\\.[\\w-]+)+\\b", format = "mailto:$0" },
}

-- Fonction de lecture et ajustement de la taille de la police lors du redimensionnement de la fenêtre
function readjust_font_size(window, pane)
  local window_dims = window:get_dimensions()
  local pane_dims = pane:get_dimensions()
  local config_overrides = {}
  local initial_font_size = 13
  config_overrides.font_size = initial_font_size
  local max_iterations = 5
  local iteration_count = 0
  local tolerance = 3
  local current_diff = window_dims.pixel_height - pane_dims.pixel_height
  local min_diff = math.abs(current_diff)
  local best_font_size = initial_font_size

  while current_diff > tolerance and iteration_count < max_iterations do
    wezterm.log_info(
      string.format(
        "Win Height: %d, Pane Height: %d, Height Diff: %d, Curr Font Size: %.2f, Cells: %d, Cell Height: %.2f",
        window_dims.pixel_height,
        pane_dims.pixel_height,
        window_dims.pixel_height - pane_dims.pixel_height,
        config_overrides.font_size,
        pane_dims.viewport_rows,
        pane_dims.pixel_height / pane_dims.viewport_rows
      )
    )
    config_overrides.font_size = config_overrides.font_size + 0.5
    window:set_config_overrides(config_overrides)
    window_dims = window:get_dimensions()
    pane_dims = pane:get_dimensions()
    current_diff = window_dims.pixel_height - pane_dims.pixel_height
    local abs_diff = math.abs(current_diff)
    if abs_diff < min_diff then
      min_diff = abs_diff
      best_font_size = config_overrides.font_size
    end
    iteration_count = iteration_count + 1
  end

  if current_diff > tolerance then
    config_overrides.font_size = best_font_size
    window:set_config_overrides(config_overrides)
  end
end

-- Retourner la configuration combinée
return config

