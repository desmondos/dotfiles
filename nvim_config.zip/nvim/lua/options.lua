require "nvchad.options"

-- add yours here!

local o = vim.o
-- o.cursorlineopt ='both' -- to enable cursorline!
o.tabstop = 4       -- Nombre de colonnes pour une tabulation
o.softtabstop = 4   -- Nombre de colonnes pour la touche Tab en mode insertion
o.shiftwidth = 4    -- Nombre de colonnes pour l'indentation (shift)
o.expandtab = false  -- Convertir les tabulations en espaces
o.textwidth = 80

vim.opt.colorcolumn = "80"    -- Affiche une colonne visuelle à 80 caractères
-- Activer l'indentation automatique
o.smartindent = true   -- Indentation intelligente
o.autoindent = true    -- Indentation automatique en fonction de la ligne précédente
o.cindent = true      -- Indentation pour les langages comme C, C++, etc.
o.linespace = 4  -- Ajuster l'espacement entre les lignes
--o.relativenumber = true

vim.opt.list = true
--vim.opt.listchars = {
--  tab = "»·",        -- Représentation des tabulations
--  trail = "·",       -- Représentation des espaces inutiles
--  eol = "↲",         -- Fin de ligne
--  nbsp = "␣",        -- Espace non sécable
--}

vim.api.nvim_create_autocmd({"FocusLost", "BufLeave"}, {
  pattern = "*",
  command = "silent! wa", -- Sauvegarde tous les fichiers ouverts
})

vim.opt.scrolloff = 8         -- Laisser toujours 8 lignes autour du curseur
vim.opt.sidescrolloff = 8     -- Laisser un espacement horizontal similaire
vim.opt.mouse = "a"           -- Active la souris dans tous les modes
vim.opt.ignorecase = true     -- Ignore la casse lors de la recherche
vim.opt.smartcase = true      -- Respecte la casse si une majuscule est présente
vim.opt.incsearch = true      -- Met en surbrillance au fur et à mesure de la frappe
vim.opt.hlsearch = true       -- Met en surbrillance toutes les occurrences trouvées
-- Activer/désactiver les numéros relatifs dynamiquement
vim.api.nvim_create_autocmd("InsertEnter", {
  pattern = "*",
  command = "set norelativenumber",
})

vim.opt.confirm = true

vim.api.nvim_create_autocmd("BufWritePre", {
  pattern = "*",
  command = [[%s/\s\+$//e]],
})

vim.api.nvim_create_autocmd("InsertLeave", {
  pattern = "*",
  command = "set relativenumber",
})

vim.opt.clipboard = "unnamedplus" -- Utilise le presse-papiers du système
